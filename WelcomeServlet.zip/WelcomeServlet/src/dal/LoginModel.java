package dal;

import java.io.Serializable;

public class LoginModel implements Serializable {
	
	private String uid;
	private String upass;
	public String getUid() {
		return uid;
	}
	public void setUid(String uid) {
		this.uid = uid;
	}
	public String getUpass() {
		return upass;
	}
	public void setUpass(String upass) {
		this.upass = upass;
	}
	
	

}
