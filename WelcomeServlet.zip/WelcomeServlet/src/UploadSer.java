

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oreilly.servlet.MultipartRequest;

import dal.*;
/**
 * Servlet implementation class UploadSer
 */
@WebServlet("/UploadSer")
public class UploadSer extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UploadSer() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try (PrintWriter out = response.getWriter()) {
	           MultipartRequest m=new MultipartRequest(request,"C:\\Users\\Hp\\workspace\\WelcomeServlet\\WebContent\\upload");
	           JDBCExample2.connect();
	           JDBCExample2.uploadfile(m.getFilesystemName("file"), m.getFilesystemName("file1"), m.getFilesystemName("file2"));
	           out.print("successfully uploaded");
	           out.print(m.getFilesystemName("file"));
	           out.print(m.getFilesystemName("file1"));
	           out.print(m.getFilesystemName("file2"));
	           
	        } catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}

}
