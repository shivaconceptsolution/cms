package student;

import java.io.IOException;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dal.JDBCExample2;

/**
 * Servlet implementation class UserLoginSer
 */
@WebServlet("/UserLoginSer")
public class UserLoginSer extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserLoginSer() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try
		{
		JDBCExample2.connect();
		ResultSet res = JDBCExample2.userLogin(request.getParameter("txtuser"),request.getParameter("txtpass"));
		if(res.next())
		{
			HttpSession ses = request.getSession();
			ses.setAttribute("sessionid",res.getString(1));
			ses.setAttribute("sessionuid",request.getParameter("txtuser"));
			response.sendRedirect("customer/userdash.jsp");
		}
		else
		{
			response.sendRedirect("customer/userlogin.jsp?q=invalid userid and password");
		}
		}
		catch(Exception ex)
		{
			
		}
	}

}
